
package net.mcreator.underworld.fuel;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.item.ItemStack;

import net.mcreator.underworld.item.OilbucketItem;
import net.mcreator.underworld.UnderworldModElements;

@UnderworldModElements.ModElement.Tag
public class OilbucketfuelFuel extends UnderworldModElements.ModElement {
	public OilbucketfuelFuel(UnderworldModElements instance) {
		super(instance, 20);
		MinecraftForge.EVENT_BUS.register(this);
	}

	@SubscribeEvent
	public void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		if (event.getItemStack().getItem() == new ItemStack(OilbucketItem.block, (int) (1)).getItem())
			event.setBurnTime(1600);
	}
}
