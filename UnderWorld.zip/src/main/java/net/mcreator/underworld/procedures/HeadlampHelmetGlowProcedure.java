package net.mcreator.underworld.procedures;

import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.underworld.UnderworldModElements;

@UnderworldModElements.ModElement.Tag
public class HeadlampHelmetGlowProcedure extends UnderworldModElements.ModElement {
	public HeadlampHelmetGlowProcedure(UnderworldModElements instance) {
		super(instance, 29);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HeadlampHelmetGlow!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.NIGHT_VISION, (int) 1, (int) 5));
	}
}
